import chess
from stockfish import Stockfish

engine = Stockfish(path="/static/stockfish")



